
import jakarta.servlet.ServletContext;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;



public class userIO {

    private static String filename = "/WEB-INF/login_credentials.txt";
    public static User getUser(String username, ServletContext c) {
        try {
            ServletContext context = c;
            InputStream is = context.getResourceAsStream(filename);
            ArrayList<String> lines = new ArrayList<String>();
            if (is != null) {
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader reader = new BufferedReader(isr);

                String text;

                // We read the file line by line and later will be displayed on the
                // browser page.
                while ((text = reader.readLine()) != null) {
                    lines.add(text);
                }
            }
            for (String line : lines) {
                String[] cred = line.split(",");
                if (cred[2].equalsIgnoreCase(username)) {
                    User u = new User();
                    u.setEmail(cred[4].toLowerCase());
                    u.setFirstName(cred[0].toLowerCase());
                    u.setLastName(cred[1].toLowerCase());
                    u.setUsername(cred[2].toLowerCase());
                    u.setPassword(cred[3].toLowerCase());
                    return u;

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
