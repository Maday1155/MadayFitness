
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;


/**
 *
 * @author user
 */
@WebServlet(urlPatterns = {"/login"})
public class login extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String filename = "/WEB-INF/login_credentials.txt";
            ServletContext context = getServletContext();
            InputStream is = context.getResourceAsStream(filename);
            String username = request.getParameter("uname");
            String password = request.getParameter("pass");
            ArrayList<String> lines = new ArrayList<String>();

            if (is != null) {
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader reader = new BufferedReader(isr);

                String text;

                // We read the file line by line and later will be displayed on the
                // browser page.
                while ((text = reader.readLine()) != null) {
                    lines.add(text);
                }
            }
            boolean flag = false;
            for (String line : lines) {
                String[] cred = line.split(",");
                if (cred[2].equalsIgnoreCase(username) && cred[3].equalsIgnoreCase(password)) {
                    User u = new User();

                    u.setEmail(cred[4].toLowerCase());
                    u.setFirstName(cred[0].toLowerCase());
                    u.setLastName(cred[1].toLowerCase());
                    u.setUsername(cred[2].toLowerCase());
                    u.setPassword(cred[3].toLowerCase());
                    HttpSession session = request.getSession(true);
                    session.setAttribute("user", u);
                    flag = true;
                    break;

                    

                }
            }


            if (flag) {
                response.sendRedirect("Dash.jsp");
            } else {
                response.sendRedirect("Error.jsp");
            }
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
