
import java.io.Serializable;

/**
 *
 * @author maday cohen
 */
public class User implements Serializable {

    private String firstName; //user firstname
    private String lastName; //users last name
    private String email;//user's email
    private String username; //username
    private String password;// password

    public User() {
    }

    /**
     * @param firstname
     * @param lastname
     * @param email
     * @param username
     * @param password
     */

    public User(String firstName, String lastName, String email, String username, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.username = username;
        this.password = password;
    }

    /**
     * @return first name of the user
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstname
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return last name of the user
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastname
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return email of the user
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return username of the user
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return password of the user
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }

}
